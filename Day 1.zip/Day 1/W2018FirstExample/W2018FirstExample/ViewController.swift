//
//  ViewController.swift
//  W2018FirstExample
//
//  Created by moxDroid on 2018-02-20.
//  Copyright © 2018 moxDroid. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblTitle: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        lblTitle.text = "I am dynamic"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnClick(_ sender: UIButton) {
        
        lblTitle.text = "Who click the button?"
    }
    
}

