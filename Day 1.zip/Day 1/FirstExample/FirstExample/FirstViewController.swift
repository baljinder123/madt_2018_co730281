//
//  ViewController.swift
//  FirstExample
//
//  Created by moxDroid on 2017-10-12.
//  Copyright © 2017 moxDroid. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    @IBOutlet weak var txtUserEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    self.title="LOGIN"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func loginClick(_ sender: UIButton) {
        
        if(txtUserEmail.text == "admin@gmail.com" && txtPassword.text == "admin123")
        {
            print("Hello, My First Click : ", txtUserEmail.text! )
        }
        else{
            print("User Email / Password incorrect")
        }
        let alert = UIAlertController(title: "Message", message: "Welcome to IOS programming", preferredStyle: UIAlertControllerStyle.actionSheet)
        let actionOk = UIAlertAction(title: "OK", style: UIAlertActionStyle.destructive, handler:{_ in print("Alert Ok")})
        alert.addAction(actionOk)
        
        let actionIgnore = UIAlertAction(title: "IGNORE", style: UIAlertActionStyle.default, handler: nil)
        alert.addAction(actionIgnore)
        let actioncancel = UIAlertAction(title: "CANCEL", style: UIAlertActionStyle.cancel, handler: nil)
        alert.addAction(actioncancel)
        self.present(alert, animated: true, completion: nil)
        
        
    }
    func validateUser()  {
        if(txtUserEmail.text == "admin@gmail.com" && txtPassword.text == "admin123")
        {
            print("Hello, My First Click : ", txtUserEmail.text! )
      
        let myStoryBoard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let nextVC = myStoryBoard .instantiateViewController(withIdentifier: "secondVC") as! secondVCViewController
        self.present(nextVC, animated: true, completion: nil)
        }
        else
        {
        let alert = UIAlertController(title: "Message", message: "Welcome to IOS programming", preferredStyle: UIAlertControllerStyle.actionSheet)
        let actionOk = UIAlertAction(title: "OK", style: UIAlertActionStyle.destructive, handler:{_ in print("Alert Ok")})
        alert.addAction(actionOk)
        
        let actionIgnore = UIAlertAction(title: "IGNORE", style: UIAlertActionStyle.default, handler: nil)
        alert.addAction(actionIgnore)
        let actioncancel = UIAlertAction(title: "CANCEL", style: UIAlertActionStyle.cancel, handler: nil)
        alert.addAction(actioncancel)
        self.present(alert, animated: true, completion: nil)
       
        }}
}

