//
//  ViewController.swift
//  FirstSample
//
//  Created by MacStudent on 2018-02-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lbl: UILabel!
    
    @IBOutlet weak var lbl2: UILabel!
    
    @IBOutlet weak var lbl3: UILabel!
    @IBOutlet weak var lbl4: UILabel!
    @IBOutlet weak var txt: UITextField!
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //lblTitle.text="I AM DYNAMIC"
        lbl.text="Baljinder Kaur"
        //lbl.textAlignment
        lbl2.text="Female"
        lbl3.text="Toronto"
        lbl4.text="student"
    }
    @IBAction func click(_ sender: UIButton) {
        lbl.text="Manpreet Kaur"
        lbl2.text="Female"
        lbl3.text="Etobicoke"
        lbl4.text="teacher"
        txt.text=lbl.text
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

